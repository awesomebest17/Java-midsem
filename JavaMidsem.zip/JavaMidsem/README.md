## Student Management System (JavaFX + SQLite)

This is a desktop Student Management System built in Java for the mid‑semester capstone. It uses **JavaFX** for the GUI and **SQLite (JDBC)** for storage.

### Requirements

- Java 17
- Maven 3.8+
- JavaFX SDK 21 (unzipped somewhere on your machine)

### How to run (from command line)

1. Update the module path in `RUN_VM_OPTIONS.txt` so it points to your JavaFX SDK `lib` folder.
2. From the project root:

```bash
mvn clean install
mvn javafx:run
```

If you prefer using `java` directly:

```bash
java @RUN_VM_OPTIONS.txt -jar target/student-management-system-1.0.0-SNAPSHOT.jar
```

### Project structure

- `src/main/java` – app code (models, repositories, services, JavaFX controllers)
- `src/main/resources/fxml` – JavaFX FXML layouts
- `data/students.db` – SQLite database (auto‑created)
- `logs/app.log` – application logs (created by Logback)
- `src/test/java` – JUnit 5 tests

### Suggested Git commit stages

- `chore: initialize Maven JavaFX project`
- `feat: add student model and SQLite schema`
- `feat: implement SQLite student repository`
- `feat: add validation and student service`
- `feat: add JavaFX layout and navigation`
- `feat: implement students screen CRUD`
- `feat: add reports, import/export, settings`
- `feat: add CSV import export and settings persistence`
- `chore: add logging config and RUN_VM_OPTIONS`
- `test: add validation and repository tests`

