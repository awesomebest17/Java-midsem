package edu.midsem.sms;

import edu.midsem.sms.repository.SQLiteStudentRepository;
import edu.midsem.sms.service.SettingsService;
import edu.midsem.sms.service.StudentService;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MainApp extends Application {

    private static final Logger log = LoggerFactory.getLogger(MainApp.class);

    @Override
    public void start(Stage primaryStage) throws Exception {
        StudentService studentService = new StudentService(new SQLiteStudentRepository());
        SettingsService settingsService = new SettingsService();

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/MainLayout.fxml"));
        Scene scene = new Scene(loader.load(), 1100, 650);

        MainLayoutController controller = loader.getController();
        controller.initializeServices(studentService, settingsService);

        primaryStage.setTitle("Student Management System");
        primaryStage.setScene(scene);
        primaryStage.show();

        log.info("Student Management System started");
    }

    @Override
    public void stop() {
        log.info("Student Management System closed");
    }

    public static void main(String[] args) {
        launch(args);
    }
}
