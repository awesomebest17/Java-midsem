package edu.midsem.sms;

import edu.midsem.sms.service.SettingsService;
import edu.midsem.sms.service.StudentService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.Node;
import java.io.IOException;

public class MainLayoutController {

    @FXML
    private BorderPane rootPane;

    @FXML
    private StackPane contentPane;

    private StudentService studentService;
    private SettingsService settingsService;

    public void initializeServices(StudentService studentService, SettingsService settingsService) {
        this.studentService = studentService;
        this.settingsService = settingsService;
        showDashboard();
    }

    @FXML
    private void showDashboard() {
        loadContent("/fxml/DashboardView.fxml");
    }

    @FXML
    private void showStudents() {
        loadContent("/fxml/StudentsView.fxml");
    }

    @FXML
    private void showReports() {
        loadContent("/fxml/ReportsView.fxml");
    }

    @FXML
    private void showImportExport() {
        loadContent("/fxml/ImportExportView.fxml");
    }

    @FXML
    private void showSettings() {
        loadContent("/fxml/SettingsView.fxml");
    }

    private void loadContent(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Node node = loader.load();

            Object controller = loader.getController();
            if (controller instanceof UsesStudentService usesStudentService) {
                usesStudentService.setStudentService(studentService);
            }
            if (controller instanceof UsesSettingsService usesSettingsService) {
                usesSettingsService.setSettingsService(settingsService);
            }

            contentPane.getChildren().setAll(node);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load view: " + fxmlPath, e);
        }
    }

    public interface UsesStudentService {
        void setStudentService(StudentService studentService);
    }

    public interface UsesSettingsService {
        void setSettingsService(SettingsService settingsService);
    }
}



