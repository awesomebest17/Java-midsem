package edu.midsem.sms.db;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseManager {

    private static final String DB_FOLDER = "data";
    private static final String DB_FILE = "students.db";
    private static final String JDBC_URL = "jdbc:sqlite:" + DB_FOLDER + "/" + DB_FILE;

    static {
        try {
            Path folder = Paths.get(DB_FOLDER);
            if (!Files.exists(folder)) {
                Files.createDirectories(folder);
            }
            initSchema();
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize database", e);
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL);
    }

    private static void initSchema() throws SQLException {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {

            String createTable = """
                    CREATE TABLE IF NOT EXISTS students (
                        student_id TEXT PRIMARY KEY,
                        full_name TEXT NOT NULL,
                        programme TEXT NOT NULL,
                        level INTEGER NOT NULL CHECK (level IN (100,200,300,400,500,600,700)),
                        gpa REAL NOT NULL CHECK (gpa >= 0.0 AND gpa <= 4.0),
                        email TEXT NOT NULL,
                        phone_number TEXT NOT NULL,
                        date_added TEXT NOT NULL,
                        status TEXT NOT NULL CHECK (status IN ('ACTIVE','INACTIVE'))
                    );
                    """;

            stmt.execute(createTable);

            String createSettings = """
                    CREATE TABLE IF NOT EXISTS settings (
                        key TEXT PRIMARY KEY,
                        value TEXT NOT NULL
                    );
                    """;

            stmt.execute(createSettings);
        }
    }
}

