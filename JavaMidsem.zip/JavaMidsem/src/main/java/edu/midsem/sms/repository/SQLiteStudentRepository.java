package edu.midsem.sms.repository;

import edu.midsem.sms.db.DatabaseManager;
import edu.midsem.sms.model.Student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class SQLiteStudentRepository implements StudentRepository {

    @Override
    public void add(Student student) {
        String sql = """
                INSERT INTO students (student_id, full_name, programme, level, gpa, email, phone_number, date_added, status)
                VALUES (?,?,?,?,?,?,?,?,?)
                """;
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            fillStudentParams(ps, student);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to add student", e);
        }
    }

    @Override
    public void update(Student student) {
        String sql = """
                UPDATE students
                SET full_name=?, programme=?, level=?, gpa=?, email=?, phone_number=?, date_added=?, status=?
                WHERE student_id=?
                """;
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, student.getFullName());
            ps.setString(2, student.getProgramme());
            ps.setInt(3, student.getLevel());
            ps.setDouble(4, student.getGpa());
            ps.setString(5, student.getEmail());
            ps.setString(6, student.getPhoneNumber());
            ps.setString(7, student.getDateAdded().toString());
            ps.setString(8, student.isActive() ? "ACTIVE" : "INACTIVE");
            ps.setString(9, student.getStudentId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to update student", e);
        }
    }

    @Override
    public void delete(String studentId) {
        String sql = "DELETE FROM students WHERE student_id=?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, studentId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to delete student", e);
        }
    }

    @Override
    public Optional<Student> findById(String studentId) {
        String sql = "SELECT * FROM students WHERE student_id=?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapRow(rs));
                }
            }
            return Optional.empty();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to find student", e);
        }
    }

    @Override
    public List<Student> findByName(String nameQuery) {
        String sql = "SELECT * FROM students WHERE LOWER(full_name) LIKE ? ORDER BY full_name";
        List<Student> result = new ArrayList<>();
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + nameQuery.toLowerCase() + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    result.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to search students by name", e);
        }
        return result;
    }

    @Override
    public List<Student> findAll() {
        String sql = "SELECT * FROM students ORDER BY full_name";
        List<Student> result = new ArrayList<>();
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                result.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to list students", e);
        }
        return result;
    }

    @Override
    public List<Student> findByFilters(String programme, Integer level, Boolean active) {
        StringBuilder sql = new StringBuilder("SELECT * FROM students WHERE 1=1");
        List<Object> params = new ArrayList<>();
        if (programme != null && !programme.isBlank()) {
            sql.append(" AND programme = ?");
            params.add(programme);
        }
        if (level != null) {
            sql.append(" AND level = ?");
            params.add(level);
        }
        if (active != null) {
            sql.append(" AND status = ?");
            params.add(active ? "ACTIVE" : "INACTIVE");
        }
        sql.append(" ORDER BY full_name");

        List<Student> result = new ArrayList<>();
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    result.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to filter students", e);
        }
        return result;
    }

    @Override
    public List<Student> findTopByGpa(int limit, String programme, Integer level) {
        StringBuilder sql = new StringBuilder("SELECT * FROM students WHERE 1=1");
        List<Object> params = new ArrayList<>();
        if (programme != null && !programme.isBlank()) {
            sql.append(" AND programme = ?");
            params.add(programme);
        }
        if (level != null) {
            sql.append(" AND level = ?");
            params.add(level);
        }
        sql.append(" ORDER BY gpa DESC, full_name ASC LIMIT ?");
        params.add(limit);

        List<Student> result = new ArrayList<>();
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    result.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to get top students", e);
        }
        return result;
    }

    @Override
    public List<Student> findAtRisk(double threshold) {
        String sql = "SELECT * FROM students WHERE gpa < ? ORDER BY gpa ASC";
        List<Student> result = new ArrayList<>();
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDouble(1, threshold);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    result.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to get at-risk students", e);
        }
        return result;
    }

    @Override
    public GpaDistribution getGpaDistribution() {
        String sql = """
                SELECT
                    SUM(CASE WHEN gpa < 2.0 THEN 1 ELSE 0 END) AS belowTwo,
                    SUM(CASE WHEN gpa >= 2.0 AND gpa < 3.0 THEN 1 ELSE 0 END) AS betweenTwoAndThree,
                    SUM(CASE WHEN gpa >= 3.0 AND gpa < 3.5 THEN 1 ELSE 0 END) AS betweenThreeAndThreeFive,
                    SUM(CASE WHEN gpa >= 3.5 THEN 1 ELSE 0 END) AS aboveThreeFive
                FROM students
                """;
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return new GpaDistribution(
                        rs.getInt("belowTwo"),
                        rs.getInt("betweenTwoAndThree"),
                        rs.getInt("betweenThreeAndThreeFive"),
                        rs.getInt("aboveThreeFive")
                );
            }
            return new GpaDistribution(0, 0, 0, 0);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to compute GPA distribution", e);
        }
    }

    @Override
    public ProgrammeSummary getProgrammeSummary() {
        String sql = """
                SELECT programme, COUNT(*) AS total, AVG(gpa) AS avg_gpa
                FROM students
                GROUP BY programme
                ORDER BY programme
                """;
        // For simplicity, return summary for "ALL" programmes using overall stats.
        String aggregateSql = "SELECT COUNT(*) AS total, AVG(gpa) AS avg_gpa FROM students";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(aggregateSql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                long total = rs.getLong("total");
                double avg = rs.getDouble("avg_gpa");
                return new ProgrammeSummary("ALL", total, Double.isNaN(avg) ? 0.0 : avg);
            }
            return new ProgrammeSummary("ALL", 0, 0.0);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to compute programme summary", e);
        }
    }

    @Override
    public boolean existsById(String studentId) {
        String sql = "SELECT 1 FROM students WHERE student_id=?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to check if student exists", e);
        }
    }

    private static void fillStudentParams(PreparedStatement ps, Student student) throws SQLException {
        ps.setString(1, student.getStudentId());
        ps.setString(2, student.getFullName());
        ps.setString(3, student.getProgramme());
        ps.setInt(4, student.getLevel());
        ps.setDouble(5, student.getGpa());
        ps.setString(6, student.getEmail());
        ps.setString(7, student.getPhoneNumber());
        ps.setString(8, student.getDateAdded().toString());
        ps.setString(9, student.isActive() ? "ACTIVE" : "INACTIVE");
    }

    private static Student mapRow(ResultSet rs) throws SQLException {
        Student s = new Student();
        s.setStudentId(rs.getString("student_id"));
        s.setFullName(rs.getString("full_name"));
        s.setProgramme(rs.getString("programme"));
        s.setLevel(rs.getInt("level"));
        s.setGpa(rs.getDouble("gpa"));
        s.setEmail(rs.getString("email"));
        s.setPhoneNumber(rs.getString("phone_number"));
        s.setDateAdded(LocalDate.parse(rs.getString("date_added")));
        s.setActive("ACTIVE".equalsIgnoreCase(rs.getString("status")));
        return s;
    }
}

