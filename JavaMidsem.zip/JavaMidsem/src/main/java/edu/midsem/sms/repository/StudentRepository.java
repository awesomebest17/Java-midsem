package edu.midsem.sms.repository;

import edu.midsem.sms.model.Student;

import java.util.List;
import java.util.Optional;

public interface StudentRepository {

    void add(Student student);

    void update(Student student);

    void delete(String studentId);

    Optional<Student> findById(String studentId);

    List<Student> findByName(String nameQuery);

    List<Student> findAll();

    List<Student> findByFilters(String programme, Integer level, Boolean active);

    List<Student> findTopByGpa(int limit, String programme, Integer level);

    List<Student> findAtRisk(double threshold);

    GpaDistribution getGpaDistribution();

    ProgrammeSummary getProgrammeSummary();

    boolean existsById(String studentId);

    record GpaDistribution(int belowTwo, int betweenTwoAndThree, int betweenThreeAndThreeFive, int aboveThreeFive) {
    }

    record ProgrammeSummary(String programme, long totalStudents, double averageGpa) {
    }
}

