package edu.midsem.sms.service;

import edu.midsem.sms.db.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SettingsService {

    public static final double DEFAULT_AT_RISK_THRESHOLD = 2.0;

    private static final String KEY_AT_RISK = "atRiskGpaThreshold";

    public double getAtRiskThreshold() {
        String sql = "SELECT value FROM settings WHERE key = ?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, KEY_AT_RISK);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Double.parseDouble(rs.getString("value"));
                }
            }
            return DEFAULT_AT_RISK_THRESHOLD;
        } catch (SQLException | NumberFormatException e) {
            return DEFAULT_AT_RISK_THRESHOLD;
        }
    }

    public void setAtRiskThreshold(double value) {
        String sql = """
                INSERT INTO settings(key, value)
                VALUES(?, ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
                """;
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, KEY_AT_RISK);
            ps.setString(2, Double.toString(value));
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to save settings", e);
        }
    }
}

