package edu.midsem.sms.service;

import edu.midsem.sms.model.Student;
import edu.midsem.sms.repository.StudentRepository;
import edu.midsem.sms.validation.StudentValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.util.List;

public class StudentService {

    private static final Logger log = LoggerFactory.getLogger(StudentService.class);

    private final StudentRepository repository;
    private final StudentValidator validator;

    public StudentService(StudentRepository repository) {
        this.repository = repository;
        this.validator = new StudentValidator(repository);
    }

    public void addStudent(Student student) {
        if (student.getDateAdded() == null) {
            student.setDateAdded(LocalDate.now());
        }
        validator.validateForCreate(student);
        repository.add(student);
        log.info("Added student {}", student.getStudentId());
    }

    public void updateStudent(Student student) {
        if (student.getDateAdded() == null) {
            student.setDateAdded(LocalDate.now());
        }
        validator.validateForUpdate(student);
        repository.update(student);
        log.info("Updated student {}", student.getStudentId());
    }

    public void deleteStudent(String studentId) {
        repository.delete(studentId);
        log.info("Deleted student {}", studentId);
    }

    public List<Student> getAllStudents() {
        return repository.findAll();
    }

    public List<Student> searchByName(String query) {
        return repository.findByName(query);
    }

    public List<Student> filterStudents(String programme, Integer level, Boolean active) {
        return repository.findByFilters(programme, level, active);
    }

    public List<Student> getTopStudents(int limit, String programme, Integer level) {
        return repository.findTopByGpa(limit, programme, level);
    }

    public List<Student> getAtRiskStudents(double threshold) {
        return repository.findAtRisk(threshold);
    }

    public StudentRepository.GpaDistribution getGpaDistribution() {
        return repository.getGpaDistribution();
    }

    public StudentRepository.ProgrammeSummary getProgrammeSummary() {
        return repository.getProgrammeSummary();
    }
}

