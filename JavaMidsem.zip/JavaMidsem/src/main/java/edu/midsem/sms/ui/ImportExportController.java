package edu.midsem.sms.ui;

import edu.midsem.sms.MainLayoutController;
import edu.midsem.sms.service.SettingsService;
import edu.midsem.sms.service.StudentService;
import edu.midsem.sms.util.CsvUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.stage.FileChooser;
import javafx.stage.Window;

import java.io.File;
import java.io.IOException;

public class ImportExportController implements MainLayoutController.UsesStudentService,
        MainLayoutController.UsesSettingsService {

    @FXML
    private ListView<String> logList;

    private final ObservableList<String> logs = FXCollections.observableArrayList();

    private StudentService studentService;
    private SettingsService settingsService;

    @Override
    public void setStudentService(StudentService studentService) {
        this.studentService = studentService;
        logList.setItems(logs);
    }

    @Override
    public void setSettingsService(SettingsService settingsService) {
        this.settingsService = settingsService;
    }

    @FXML
    private void onImportStudents() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Import students from CSV");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV files", "*.csv"));
        File file = chooser.showOpenDialog(getWindow());
        if (file == null) {
            return;
        }
        try {
            CsvUtils.ImportResult result = CsvUtils.readStudents(file);
            int success = 0;
            for (var s : result.validStudents()) {
                try {
                    studentService.addStudent(s);
                    success++;
                } catch (Exception e) {
                    logs.add("Validation failed for " + s.getStudentId() + ": " + e.getMessage());
                }
            }
            if (!result.errorLines().isEmpty()) {
                File errorFile = new File(file.getParentFile(), "import_errors.csv");
                java.nio.file.Files.write(errorFile.toPath(), result.errorLines());
                logs.add("Import completed. Success: " + success + ", errors: "
                        + result.errorLines().size() + ". Error report: " + errorFile.getAbsolutePath());
            } else {
                logs.add("Import completed. Success: " + success + ", no parse errors.");
            }
        } catch (IOException e) {
            logs.add("Failed to import: " + e.getMessage());
        }
    }

    @FXML
    private void onExportStudents() {
        File target = chooseCsvSaveLocation("Export full student list");
        if (target == null) {
            return;
        }
        try {
            CsvUtils.writeStudents(target, studentService.getAllStudents());
            logs.add("Exported full list to: " + target.getAbsolutePath());
        } catch (IOException e) {
            logs.add("Failed to export: " + e.getMessage());
        }
    }

    @FXML
    private void onExportTopPerformers() {
        File target = chooseCsvSaveLocation("Export top performers");
        if (target == null) {
            return;
        }
        try {
            CsvUtils.writeStudents(target, studentService.getTopStudents(10, null, null));
            logs.add("Exported top performers to: " + target.getAbsolutePath());
        } catch (IOException e) {
            logs.add("Failed to export: " + e.getMessage());
        }
    }

    @FXML
    private void onExportAtRisk() {
        File target = chooseCsvSaveLocation("Export at risk students");
        if (target == null) {
            return;
        }
        try {
            double threshold = settingsService != null
                    ? settingsService.getAtRiskThreshold()
                    : SettingsService.DEFAULT_AT_RISK_THRESHOLD;
            CsvUtils.writeStudents(target, studentService.getAtRiskStudents(threshold));
            logs.add("Exported at risk students to: " + target.getAbsolutePath());
        } catch (IOException e) {
            logs.add("Failed to export: " + e.getMessage());
        }
    }

    private File chooseCsvSaveLocation(String title) {
        FileChooser chooser = new FileChooser();
        chooser.setTitle(title);
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV files", "*.csv"));
        chooser.setInitialFileName("report.csv");
        return chooser.showSaveDialog(getWindow());
    }

    private Window getWindow() {
        return logList.getScene().getWindow();
    }
}

