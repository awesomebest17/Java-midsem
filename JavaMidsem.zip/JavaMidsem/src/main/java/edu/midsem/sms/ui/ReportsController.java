package edu.midsem.sms.ui;

import edu.midsem.sms.MainLayoutController;
import edu.midsem.sms.model.Student;
import edu.midsem.sms.repository.StudentRepository;
import edu.midsem.sms.service.SettingsService;
import edu.midsem.sms.service.StudentService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class ReportsController implements MainLayoutController.UsesStudentService,
        MainLayoutController.UsesSettingsService {

    @FXML
    private ComboBox<String> reportType;
    @FXML
    private ComboBox<String> programmeFilter;
    @FXML
    private ComboBox<String> levelFilter;

    @FXML
    private TableView<ReportRow> reportTable;
    @FXML
    private TableColumn<ReportRow, String> colA;
    @FXML
    private TableColumn<ReportRow, String> colB;
    @FXML
    private TableColumn<ReportRow, String> colC;
    @FXML
    private TableColumn<ReportRow, String> colD;

    private final ObservableList<ReportRow> rows = FXCollections.observableArrayList();

    private StudentService studentService;
    private SettingsService settingsService;

    @Override
    public void setStudentService(StudentService studentService) {
        this.studentService = studentService;
        initControls();
    }

    @Override
    public void setSettingsService(SettingsService settingsService) {
        this.settingsService = settingsService;
    }

    private void initControls() {
        reportType.getItems().addAll(
                "Top performers",
                "At risk students",
                "GPA distribution",
                "Programme summary"
        );
        reportType.getSelectionModel().selectFirst();

        levelFilter.getItems().addAll("Any", "100", "200", "300", "400", "500", "600", "700");
        levelFilter.getSelectionModel().selectFirst();

        colA.setCellValueFactory(new PropertyValueFactory<>("colA"));
        colB.setCellValueFactory(new PropertyValueFactory<>("colB"));
        colC.setCellValueFactory(new PropertyValueFactory<>("colC"));
        colD.setCellValueFactory(new PropertyValueFactory<>("colD"));
        reportTable.setItems(rows);
    }

    @FXML
    private void onRunReport() {
        String selected = reportType.getSelectionModel().getSelectedItem();
        rows.clear();
        if (selected == null) {
            return;
        }

        switch (selected) {
            case "Top performers" -> runTopPerformers();
            case "At risk students" -> runAtRisk();
            case "GPA distribution" -> runGpaDistribution();
            case "Programme summary" -> runProgrammeSummary();
            default -> {
            }
        }
    }

    @FXML
    private void onExportReport() {
        // CSV export will be wired later in CSV stage.
    }

    private void runTopPerformers() {
        String programme = programmeFilter.getValue();
        Integer level = parseLevel(levelFilter.getValue());
        for (Student s : studentService.getTopStudents(10, blankToNull(programme), level)) {
            rows.add(new ReportRow(
                    s.getStudentId(),
                    s.getFullName(),
                    s.getProgramme() + " L" + s.getLevel(),
                    String.format("%.2f", s.getGpa())
            ));
        }
    }

    private void runAtRisk() {
        double threshold = settingsService != null
                ? settingsService.getAtRiskThreshold()
                : SettingsService.DEFAULT_AT_RISK_THRESHOLD;
        for (Student s : studentService.getAtRiskStudents(threshold)) {
            rows.add(new ReportRow(
                    s.getStudentId(),
                    s.getFullName(),
                    s.getProgramme() + " L" + s.getLevel(),
                    String.format("%.2f", s.getGpa())
            ));
        }
    }

    private void runGpaDistribution() {
        StudentRepository.GpaDistribution dist = studentService.getGpaDistribution();
        rows.add(new ReportRow("<2.0", "Below threshold", String.valueOf(dist.belowTwo()), ""));
        rows.add(new ReportRow("2.0 - 2.99", "", String.valueOf(dist.betweenTwoAndThree()), ""));
        rows.add(new ReportRow("3.0 - 3.49", "", String.valueOf(dist.betweenThreeAndThreeFive()), ""));
        rows.add(new ReportRow(">= 3.5", "", String.valueOf(dist.aboveThreeFive()), ""));
    }

    private void runProgrammeSummary() {
        StudentRepository.ProgrammeSummary summary = studentService.getProgrammeSummary();
        rows.add(new ReportRow(
                summary.programme(),
                "Total students",
                String.valueOf(summary.totalStudents()),
                String.format("Avg GPA: %.2f", summary.averageGpa())
        ));
    }

    private static Integer parseLevel(String value) {
        if (value == null || value.equals("Any") || value.isBlank()) {
            return null;
        }
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static String blankToNull(String s) {
        return (s == null || s.isBlank()) ? null : s;
    }

    public static class ReportRow {
        private final String colA;
        private final String colB;
        private final String colC;
        private final String colD;

        public ReportRow(String colA, String colB, String colC, String colD) {
            this.colA = colA;
            this.colB = colB;
            this.colC = colC;
            this.colD = colD;
        }

        public String getColA() {
            return colA;
        }

        public String getColB() {
            return colB;
        }

        public String getColC() {
            return colC;
        }

        public String getColD() {
            return colD;
        }
    }
}

