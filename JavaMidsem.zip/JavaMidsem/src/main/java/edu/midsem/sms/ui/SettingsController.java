package edu.midsem.sms.ui;

import edu.midsem.sms.MainLayoutController;
import edu.midsem.sms.service.SettingsService;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

public class SettingsController implements MainLayoutController.UsesSettingsService {

    @FXML
    private TextField atRiskThresholdField;

    private SettingsService settingsService;

    @Override
    public void setSettingsService(SettingsService settingsService) {
        this.settingsService = settingsService;
        double value = settingsService.getAtRiskThreshold();
        atRiskThresholdField.setText(String.valueOf(value));
    }

    @FXML
    private void onSave() {
        try {
            double value = Double.parseDouble(atRiskThresholdField.getText());
            if (value < 0.0 || value > 4.0) {
                throw new IllegalArgumentException("Threshold must be between 0.0 and 4.0");
            }
            settingsService.setAtRiskThreshold(value);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Settings");
            alert.setHeaderText("Saved");
            alert.setContentText("Settings saved (in-memory for now).");
            alert.showAndWait();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Settings");
            alert.setHeaderText("Invalid value");
            alert.setContentText(e.getMessage());
            alert.showAndWait();
        }
    }
}

