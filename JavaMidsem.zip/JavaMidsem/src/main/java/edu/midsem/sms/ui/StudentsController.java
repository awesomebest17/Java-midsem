package edu.midsem.sms.ui;

import edu.midsem.sms.MainLayoutController;
import edu.midsem.sms.model.Student;
import edu.midsem.sms.service.StudentService;
import edu.midsem.sms.validation.ValidationException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;

import java.time.LocalDate;
import java.util.Optional;

public class StudentsController implements MainLayoutController.UsesStudentService {

    @FXML
    private TableView<Student> studentsTable;
    @FXML
    private TableColumn<Student, String> colId;
    @FXML
    private TableColumn<Student, String> colName;
    @FXML
    private TableColumn<Student, String> colProgramme;
    @FXML
    private TableColumn<Student, Integer> colLevel;
    @FXML
    private TableColumn<Student, Double> colGpa;
    @FXML
    private TableColumn<Student, String> colEmail;
    @FXML
    private TableColumn<Student, String> colPhone;
    @FXML
    private TableColumn<Student, String> colStatus;

    @FXML
    private TextField searchField;
    @FXML
    private ComboBox<String> programmeFilter;
    @FXML
    private ComboBox<String> levelFilter;
    @FXML
    private ComboBox<String> statusFilter;

    private final ObservableList<Student> students = FXCollections.observableArrayList();

    private StudentService studentService;

    @Override
    public void setStudentService(StudentService studentService) {
        this.studentService = studentService;
        initTable();
        loadStudents();
    }

    private void initTable() {
        colId.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        colName.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        colProgramme.setCellValueFactory(new PropertyValueFactory<>("programme"));
        colLevel.setCellValueFactory(new PropertyValueFactory<>("level"));
        colGpa.setCellValueFactory(new PropertyValueFactory<>("gpa"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colPhone.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        colStatus.setCellValueFactory(cd -> javafx.beans.binding.Bindings.createStringBinding(
                () -> cd.getValue().isActive() ? "Active" : "Inactive"
        ));
        studentsTable.setItems(students);

        statusFilter.getItems().addAll("Any", "Active", "Inactive");
        statusFilter.getSelectionModel().selectFirst();
    }

    private void loadStudents() {
        students.setAll(studentService.getAllStudents());
    }

    @FXML
    private void onRefresh() {
        loadStudents();
    }

    @FXML
    private void onSearch() {
        String query = searchField.getText();
        if (query == null || query.isBlank()) {
            loadStudents();
        } else {
            students.setAll(studentService.searchByName(query));
        }
    }

    @FXML
    private void onAdd() {
        Student newStudent = showStudentDialog(new Student());
        if (newStudent != null) {
            try {
                newStudent.setDateAdded(LocalDate.now());
                newStudent.setActive(true);
                studentService.addStudent(newStudent);
                loadStudents();
            } catch (ValidationException ex) {
                showError("Validation error", String.join("\n", ex.getErrors()));
            } catch (Exception ex) {
                showError("Error adding student", ex.getMessage());
            }
        }
    }

    @FXML
    private void onEdit() {
        Student selected = studentsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showError("No selection", "Please select a student to edit.");
            return;
        }
        Student edited = showStudentDialog(selected);
        if (edited != null) {
            try {
                edited.setDateAdded(selected.getDateAdded());
                studentService.updateStudent(edited);
                loadStudents();
            } catch (ValidationException ex) {
                showError("Validation error", String.join("\n", ex.getErrors()));
            } catch (Exception ex) {
                showError("Error updating student", ex.getMessage());
            }
        }
    }

    @FXML
    private void onDelete() {
        Student selected = studentsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showError("No selection", "Please select a student to delete.");
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Delete student");
        confirm.setHeaderText("Are you sure you want to delete this student?");
        confirm.setContentText(selected.getStudentId() + " - " + selected.getFullName());
        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                studentService.deleteStudent(selected.getStudentId());
                loadStudents();
            } catch (Exception ex) {
                showError("Error deleting student", ex.getMessage());
            }
        }
    }

    private Student showStudentDialog(Student original) {
        Dialog<Student> dialog = new Dialog<>();
        dialog.setTitle("Student");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        TextField idField = new TextField(original.getStudentId());
        idField.setPromptText("Student ID");
        TextField nameField = new TextField(original.getFullName());
        TextField programmeField = new TextField(original.getProgramme());
        TextField levelField = new TextField(original.getLevel() == 0 ? "" : String.valueOf(original.getLevel()));
        TextField gpaField = new TextField(original.getGpa() == 0.0 ? "" : String.valueOf(original.getGpa()));
        TextField emailField = new TextField(original.getEmail());
        TextField phoneField = new TextField(original.getPhoneNumber());

        CheckBox activeBox = new CheckBox("Active");
        activeBox.setSelected(original.isActive());

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        grid.addRow(0, new Label("Student ID:"), idField);
        grid.addRow(1, new Label("Full name:"), nameField);
        grid.addRow(2, new Label("Programme:"), programmeField);
        grid.addRow(3, new Label("Level:"), levelField);
        grid.addRow(4, new Label("GPA:"), gpaField);
        grid.addRow(5, new Label("Email:"), emailField);
        grid.addRow(6, new Label("Phone:"), phoneField);
        grid.addRow(7, new Label("Status:"), activeBox);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(button -> {
            if (button == ButtonType.OK) {
                Student s = new Student();
                s.setStudentId(idField.getText().trim());
                s.setFullName(nameField.getText().trim());
                s.setProgramme(programmeField.getText().trim());
                try {
                    s.setLevel(Integer.parseInt(levelField.getText().trim()));
                } catch (NumberFormatException e) {
                    s.setLevel(0);
                }
                try {
                    s.setGpa(Double.parseDouble(gpaField.getText().trim()));
                } catch (NumberFormatException e) {
                    s.setGpa(-1);
                }
                s.setEmail(emailField.getText().trim());
                s.setPhoneNumber(phoneField.getText().trim());
                s.setActive(activeBox.isSelected());
                s.setDateAdded(original.getDateAdded() != null ? original.getDateAdded() : LocalDate.now());
                return s;
            }
            return null;
        });

        Optional<Student> result = dialog.showAndWait();
        return result.orElse(null);
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

