package edu.midsem.sms.util;

import edu.midsem.sms.model.Student;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public final class CsvUtils {

    private CsvUtils() {
    }

    public static void writeStudents(File file, List<Student> students) throws IOException {
        try (Writer writer = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8);
             BufferedWriter bw = new BufferedWriter(writer)) {
            bw.write("studentId,fullName,programme,level,gpa,email,phoneNumber,dateAdded,status");
            bw.newLine();
            for (Student s : students) {
                bw.write(String.join(",",
                        escape(s.getStudentId()),
                        escape(s.getFullName()),
                        escape(s.getProgramme()),
                        String.valueOf(s.getLevel()),
                        String.valueOf(s.getGpa()),
                        escape(s.getEmail()),
                        escape(s.getPhoneNumber()),
                        s.getDateAdded() != null ? s.getDateAdded().toString() : "",
                        s.isActive() ? "ACTIVE" : "INACTIVE"
                ));
                bw.newLine();
            }
        }
    }

    public record ImportResult(List<Student> validStudents, List<String> errorLines) {
    }

    public static ImportResult readStudents(File file) throws IOException {
        List<Student> students = new ArrayList<>();
        List<String> errors = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line = br.readLine(); // header
            int lineNo = 1;
            while ((line = br.readLine()) != null) {
                lineNo++;
                if (line.isBlank()) {
                    continue;
                }
                try {
                    String[] parts = parseCsvLine(line, 9);
                    Student s = new Student();
                    s.setStudentId(parts[0]);
                    s.setFullName(parts[1]);
                    s.setProgramme(parts[2]);
                    s.setLevel(Integer.parseInt(parts[3]));
                    s.setGpa(Double.parseDouble(parts[4]));
                    s.setEmail(parts[5]);
                    s.setPhoneNumber(parts[6]);
                    s.setDateAdded(parts[7].isBlank() ? LocalDate.now() : LocalDate.parse(parts[7]));
                    s.setActive("ACTIVE".equalsIgnoreCase(parts[8]));
                    students.add(s);
                } catch (Exception e) {
                    errors.add("Line " + lineNo + ": " + e.getMessage() + " | " + line);
                }
            }
        }

        return new ImportResult(students, errors);
    }

    private static String escape(String value) {
        if (value == null) {
            return "";
        }
        boolean needQuotes = value.contains(",") || value.contains("\"") || value.contains("\n") || value.contains("\r");
        String escaped = value.replace("\"", "\"\"");
        return needQuotes ? "\"" + escaped + "\"" : escaped;
    }

    private static String[] parseCsvLine(String line, int expectedColumns) {
        List<String> tokens = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (inQuotes) {
                if (c == '"') {
                    if (i + 1 < line.length() && line.charAt(i + 1) == '"') {
                        current.append('"');
                        i++;
                    } else {
                        inQuotes = false;
                    }
                } else {
                    current.append(c);
                }
            } else {
                if (c == ',') {
                    tokens.add(current.toString());
                    current.setLength(0);
                } else if (c == '"') {
                    inQuotes = true;
                } else {
                    current.append(c);
                }
            }
        }
        tokens.add(current.toString());
        if (tokens.size() != expectedColumns) {
            throw new IllegalArgumentException("Expected " + expectedColumns + " columns but got " + tokens.size());
        }
        return tokens.toArray(new String[0]);
    }
}

