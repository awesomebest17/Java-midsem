package edu.midsem.sms.validation;

import edu.midsem.sms.model.Student;
import edu.midsem.sms.repository.StudentRepository;

import java.util.ArrayList;
import java.util.List;

public class StudentValidator {

    private final StudentRepository repository;

    public StudentValidator(StudentRepository repository) {
        this.repository = repository;
    }

    public void validateForCreate(Student student) {
        List<String> errors = validateCommon(student);
        if (student.getStudentId() == null || student.getStudentId().isBlank()) {
            errors.add("Student ID is required");
        } else if (repository.existsById(student.getStudentId())) {
            errors.add("Student ID must be unique");
        }
        if (!errors.isEmpty()) {
            throw new ValidationException(errors);
        }
    }

    public void validateForUpdate(Student student) {
        List<String> errors = validateCommon(student);
        if (!errors.isEmpty()) {
            throw new ValidationException(errors);
        }
    }

    private List<String> validateCommon(Student s) {
        List<String> errors = new ArrayList<>();

        String id = s.getStudentId();
        if (id == null || id.isBlank()) {
            errors.add("Student ID is required");
        } else {
            if (id.length() < 4 || id.length() > 20) {
                errors.add("Student ID must be between 4 and 20 characters");
            }
            if (!id.matches("[A-Za-z0-9]+")) {
                errors.add("Student ID must contain only letters and digits");
            }
        }

        String name = s.getFullName();
        if (name == null || name.isBlank()) {
            errors.add("Full name is required");
        } else {
            if (name.length() < 2 || name.length() > 60) {
                errors.add("Full name must be between 2 and 60 characters");
            }
            if (!name.matches("[A-Za-z .'-]+")) {
                errors.add("Full name must not contain digits");
            }
        }

        if (s.getProgramme() == null || s.getProgramme().isBlank()) {
            errors.add("Programme is required");
        }

        int level = s.getLevel();
        if (level != 100 && level != 200 && level != 300 && level != 400 && level != 500 && level != 600 && level != 700) {
            errors.add("Level must be one of 100, 200, 300, 400, 500, 600, 700");
        }

        double gpa = s.getGpa();
        if (gpa < 0.0 || gpa > 4.0) {
            errors.add("GPA must be between 0.0 and 4.0");
        }

        String email = s.getEmail();
        if (email == null || email.isBlank()) {
            errors.add("Email is required");
        } else if (!email.contains("@") || !email.contains(".")) {
            errors.add("Email must contain @ and .");
        }

        String phone = s.getPhoneNumber();
        if (phone == null || phone.isBlank()) {
            errors.add("Phone number is required");
        } else {
            if (!phone.matches("\\d+")) {
                errors.add("Phone number must contain digits only");
            }
            if (phone.length() < 10 || phone.length() > 15) {
                errors.add("Phone number must be between 10 and 15 digits");
            }
        }

        if (s.getDateAdded() == null) {
            errors.add("Date added is required");
        }

        return errors;
    }
}

