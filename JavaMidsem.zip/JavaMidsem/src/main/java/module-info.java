module edu.midsem.sms {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires org.slf4j;
    requires org.xerial.sqlitejdbc;

    // Allow FXML to access controller classes reflectively
    opens edu.midsem.sms to javafx.fxml;
    opens edu.midsem.sms.ui to javafx.fxml;

    exports edu.midsem.sms;
}