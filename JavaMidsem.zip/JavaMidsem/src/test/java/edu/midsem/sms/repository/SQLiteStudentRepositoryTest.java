package edu.midsem.sms.repository;

import edu.midsem.sms.db.DatabaseManager;
import edu.midsem.sms.model.Student;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class SQLiteStudentRepositoryTest {

    private SQLiteStudentRepository repo;

    @BeforeEach
    void setUp() throws SQLException {
        repo = new SQLiteStudentRepository();
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate("DELETE FROM students");
        }
    }

    private Student sample(String id, double gpa) {
        Student s = new Student();
        s.setStudentId(id);
        s.setFullName("Name " + id);
        s.setProgramme("CS");
        s.setLevel(200);
        s.setGpa(gpa);
        s.setEmail(id + "@example.com");
        s.setPhoneNumber("0551234567");
        s.setDateAdded(LocalDate.now());
        s.setActive(true);
        return s;
    }

    @Test
    void addAndFindByIdWorks() {
        Student s = sample("S1", 3.0);
        repo.add(s);
        Optional<Student> loaded = repo.findById("S1");
        assertTrue(loaded.isPresent());
        assertEquals("S1", loaded.get().getStudentId());
    }

    @Test
    void updateChangesData() {
        Student s = sample("S2", 2.5);
        repo.add(s);
        s.setFullName("Updated Name");
        repo.update(s);
        Student loaded = repo.findById("S2").orElseThrow();
        assertEquals("Updated Name", loaded.getFullName());
    }

    @Test
    void deleteRemovesStudent() {
        Student s = sample("S3", 2.0);
        repo.add(s);
        repo.delete("S3");
        assertTrue(repo.findById("S3").isEmpty());
    }

    @Test
    void topByGpaReturnsOrdered() {
        repo.add(sample("A", 2.0));
        repo.add(sample("B", 3.5));
        repo.add(sample("C", 3.0));
        List<Student> top = repo.findTopByGpa(2, null, null);
        assertEquals(2, top.size());
        assertEquals("B", top.get(0).getStudentId());
    }
}

