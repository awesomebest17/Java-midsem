package edu.midsem.sms.validation;

import edu.midsem.sms.model.Student;
import edu.midsem.sms.repository.StudentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class StudentValidatorTest {

    private StudentValidator validator;

    @BeforeEach
    void setUp() {
        // Repository stub that reports no existing IDs
        StudentRepository stubRepo = new StudentRepository() {
            @Override public void add(Student student) {}
            @Override public void update(Student student) {}
            @Override public void delete(String studentId) {}
            @Override public Optional<Student> findById(String studentId) { return Optional.empty(); }
            @Override public List<Student> findByName(String nameQuery) { return Collections.emptyList(); }
            @Override public List<Student> findAll() { return Collections.emptyList(); }
            @Override public List<Student> findByFilters(String programme, Integer level, Boolean active) { return Collections.emptyList(); }
            @Override public List<Student> findTopByGpa(int limit, String programme, Integer level) { return Collections.emptyList(); }
            @Override public List<Student> findAtRisk(double threshold) { return Collections.emptyList(); }
            @Override public GpaDistribution getGpaDistribution() { return new GpaDistribution(0,0,0,0); }
            @Override public ProgrammeSummary getProgrammeSummary() { return new ProgrammeSummary("ALL",0,0.0); }
            @Override public boolean existsById(String studentId) { return false; }
        };
        validator = new StudentValidator(stubRepo);
    }

    private Student validStudent() {
        Student s = new Student();
        s.setStudentId("ABCD1234");
        s.setFullName("John Doe");
        s.setProgramme("CS");
        s.setLevel(200);
        s.setGpa(3.2);
        s.setEmail("john@example.com");
        s.setPhoneNumber("0551234567");
        s.setDateAdded(LocalDate.now());
        s.setActive(true);
        return s;
    }

    @Test
    void validStudentPassesValidation() {
        assertDoesNotThrow(() -> validator.validateForCreate(validStudent()));
    }

    @Test
    void invalidIdLengthFails() {
        Student s = validStudent();
        s.setStudentId("A");
        ValidationException ex = assertThrows(ValidationException.class, () -> validator.validateForCreate(s));
        assertTrue(ex.getErrors().stream().anyMatch(msg -> msg.contains("between 4 and 20")));
    }

    @Test
    void invalidGpaFails() {
        Student s = validStudent();
        s.setGpa(4.5);
        ValidationException ex = assertThrows(ValidationException.class, () -> validator.validateForCreate(s));
        assertTrue(ex.getErrors().stream().anyMatch(msg -> msg.contains("between 0.0 and 4.0")));
    }

    @Test
    void invalidEmailFails() {
        Student s = validStudent();
        s.setEmail("invalid-email");
        ValidationException ex = assertThrows(ValidationException.class, () -> validator.validateForCreate(s));
        assertTrue(ex.getErrors().stream().anyMatch(msg -> msg.contains("Email must contain")));
    }

    @Test
    void invalidPhoneFails() {
        Student s = validStudent();
        s.setPhoneNumber("abc");
        ValidationException ex = assertThrows(ValidationException.class, () -> validator.validateForCreate(s));
        assertFalse(ex.getErrors().isEmpty());
    }
}

